/* USER CODE BEGIN Header */



/**



  ******************************************************************************



  * @file           : main.c



  * @brief          : Main program body



  ******************************************************************************



  * @attention



  *



  * Copyright (c) 2025 STMicroelectronics.



  * All rights reserved.



  *



  * This software is licensed under terms that can be found in the LICENSE file



  * in the root directory of this software component.



  * If no LICENSE file comes with this software, it is provided AS-IS.



  *



  ******************************************************************************



  */



/* USER CODE END Header */



/* Includes ------------------------------------------------------------------*/



#include "main.h"



#include <string.h>







UART_HandleTypeDef huart2;



UART_HandleTypeDef huart3;



ADC_HandleTypeDef hadc1;



ADC_HandleTypeDef hadc2;      // Ajoute cette ligne si tu utilises ADC2 !



TIM_HandleTypeDef htim2;      // Ajoute si tu utilises TIM2 !



TIM_HandleTypeDef htim3;      // Ajoute si tu utilises TIM3 !



void SystemClock_Config(void);



void MX_GPIO_Init(void);



void MX_ADC1_Init(void);



void MX_ADC2_Init(void);      // Si tu utilises ADC2 !



void MX_TIM2_Init(void);      // Si tu utilises TIM2 !



void MX_TIM3_Init(void);      // Si tu utilises TIM3 !



void MX_USART2_UART_Init(void);



void MX_USART3_UART_Init(void);







uint8_t rxBuf_ctrl[4];   // consigne reçue (float)



uint8_t txBuf_cmd[4];    // commande envoyée (float)



float consigne = 0.0f, mesure = 0.0f, commande = 0.0f;







// PID simple discret


float PID_Update(float setpoint, float input)
{
    static float prev_error = 0.0f, integral = 0.0f;
    float Ts = 0.01f;
    float kp = 5.8f, ki = 5.0f, kd = 1.1f;

    float error = setpoint - input;
    float derivative = (error - prev_error) / Ts;

    float output_no_limit = kp * error + ki * integral + kd * derivative;

    // Anti-windup : met à jour l’intégrale seulement si sortie pas saturée
    if (output_no_limit < 3.3f && output_no_limit > 0.0f)
    {
        integral += error * Ts;
    }

    float output = kp * error + ki * integral + kd * derivative;

    // Limitation sortie
    if (output > 3.3f) output = 3.3f;
    else if (output < 0.0f) output = 0.0f;

    prev_error = error;
    return output;
}






int main(void)

{

    HAL_Init();

    SystemClock_Config();

    MX_GPIO_Init();

    MX_ADC1_Init();

    MX_USART3_UART_Init();

    MX_TIM2_Init();



    // Démarre le PWM sur TIM2_CH1 (PA0)

    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);



    while (1)

    {

        // 1. Reçoit la consigne depuis l'interface (UART3 RX, 4 octets)

        HAL_UART_Receive(&huart3, rxBuf_ctrl, 4, HAL_MAX_DELAY);

        memcpy(&consigne, rxBuf_ctrl, 4);



        // 2. Lis la mesure analogique sur ADC (PA4 relié au DAC de l’interface)

        HAL_ADC_Start(&hadc1);

        HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);

        uint32_t adc_val = HAL_ADC_GetValue(&hadc1);

        HAL_ADC_Stop(&hadc1);

        mesure = (adc_val * 3.3f) / 4095.0f;



        // 3. Calcul PID

        commande = PID_Update(consigne, mesure);



        // 4. Génère le PWM selon la commande (0-3.3V)

        uint32_t pwm_period = __HAL_TIM_GET_AUTORELOAD(&htim2);  // exemple: 65535

        uint32_t pwm_val = (uint32_t)(commande / 3.3f * pwm_period);

        if (pwm_val > pwm_period) pwm_val = pwm_period;

        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, pwm_val);



        // 5. Blink debug

        HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);

    }

}



/**



  * @brief System Clock Configuration



  * @retval None



  */



void SystemClock_Config(void)



{



  RCC_OscInitTypeDef RCC_OscInitStruct = {0};



  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};



  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};







  /** Initializes the RCC Oscillators according to the specified parameters



  * in the RCC_OscInitTypeDef structure.



  */



  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;



  RCC_OscInitStruct.HSIState = RCC_HSI_ON;



  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;



  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;



  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;



  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;



  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)



  {



    Error_Handler();



  }







  /** Initializes the CPU, AHB and APB buses clocks



  */



  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK



                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;



  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;



  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;



  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;



  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;







  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)



  {



    Error_Handler();



  }



  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;



  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV2;



  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)



  {



    Error_Handler();



  }



}







/**



  * @brief ADC1 Initialization Function



  * @param None



  * @retval None



  */



 void MX_ADC1_Init(void)



{







  /* USER CODE BEGIN ADC1_Init 0 */







  /* USER CODE END ADC1_Init 0 */







  ADC_AnalogWDGConfTypeDef AnalogWDGConfig = {0};



  ADC_ChannelConfTypeDef sConfig = {0};







  /* USER CODE BEGIN ADC1_Init 1 */







  /* USER CODE END ADC1_Init 1 */







  /** Common config



  */



  hadc1.Instance = ADC1;



  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;



  hadc1.Init.ContinuousConvMode = DISABLE;



  hadc1.Init.DiscontinuousConvMode = DISABLE;



  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;



  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;



  hadc1.Init.NbrOfConversion = 1;



  if (HAL_ADC_Init(&hadc1) != HAL_OK)



  {



    Error_Handler();



  }







  /** Configure Analog WatchDog 1



  */



  AnalogWDGConfig.WatchdogMode = ADC_ANALOGWATCHDOG_SINGLE_REG;



  AnalogWDGConfig.HighThreshold = 0;



  AnalogWDGConfig.LowThreshold = 0;



  AnalogWDGConfig.Channel = ADC_CHANNEL_0;



  AnalogWDGConfig.ITMode = DISABLE;



  if (HAL_ADC_AnalogWDGConfig(&hadc1, &AnalogWDGConfig) != HAL_OK)



  {



    Error_Handler();



  }







  /** Configure Regular Channel



  */



  sConfig.Channel = ADC_CHANNEL_0;



  sConfig.Rank = ADC_REGULAR_RANK_1;



  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;



  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)



  {



    Error_Handler();



  }



  /* USER CODE BEGIN ADC1_Init 2 */







  /* USER CODE END ADC1_Init 2 */







}







/**



  * @brief ADC2 Initialization Function



  * @param None



  * @retval None



  */



void MX_ADC2_Init(void)



{







  /* USER CODE BEGIN ADC2_Init 0 */







  /* USER CODE END ADC2_Init 0 */







  ADC_ChannelConfTypeDef sConfig = {0};







  /* USER CODE BEGIN ADC2_Init 1 */







  /* USER CODE END ADC2_Init 1 */







  /** Common config



  */



  hadc2.Instance = ADC2;



  hadc2.Init.ScanConvMode = ADC_SCAN_DISABLE;



  hadc2.Init.ContinuousConvMode = DISABLE;



  hadc2.Init.DiscontinuousConvMode = DISABLE;



  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;



  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;



  hadc2.Init.NbrOfConversion = 1;



  if (HAL_ADC_Init(&hadc2) != HAL_OK)



  {



    Error_Handler();



  }







  /** Configure Regular Channel



  */



  sConfig.Channel = ADC_CHANNEL_0;



  sConfig.Rank = ADC_REGULAR_RANK_1;



  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;



  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)



  {



    Error_Handler();



  }



  /* USER CODE BEGIN ADC2_Init 2 */







  /* USER CODE END ADC2_Init 2 */







}







/**



  * @brief TIM2 Initialization Function



  * @param None



  * @retval None



  */



 void MX_TIM2_Init(void)



{







  /* USER CODE BEGIN TIM2_Init 0 */







  /* USER CODE END TIM2_Init 0 */







  TIM_ClockConfigTypeDef sClockSourceConfig = {0};



  TIM_MasterConfigTypeDef sMasterConfig = {0};



  TIM_OC_InitTypeDef sConfigOC = {0};







  /* USER CODE BEGIN TIM2_Init 1 */







  /* USER CODE END TIM2_Init 1 */



  htim2.Instance = TIM2;



  htim2.Init.Prescaler = 79;



  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;



  htim2.Init.Period = 999;



  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;



  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;



  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)



  {



    Error_Handler();



  }



  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;



  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)



  {



    Error_Handler();



  }



  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)



  {



    Error_Handler();



  }



  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;



  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;



  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)



  {



    Error_Handler();



  }



  sConfigOC.OCMode = TIM_OCMODE_PWM1;



  sConfigOC.Pulse = 0;



  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;



  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;



  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)



  {



    Error_Handler();



  }



  /* USER CODE BEGIN TIM2_Init 2 */







  /* USER CODE END TIM2_Init 2 */



  HAL_TIM_MspPostInit(&htim2);







}







/**



  * @brief TIM3 Initialization Function



  * @param None



  * @retval None



  */



void MX_TIM3_Init(void)



{







  /* USER CODE BEGIN TIM3_Init 0 */







  /* USER CODE END TIM3_Init 0 */







  TIM_ClockConfigTypeDef sClockSourceConfig = {0};



  TIM_MasterConfigTypeDef sMasterConfig = {0};







  /* USER CODE BEGIN TIM3_Init 1 */







  /* USER CODE END TIM3_Init 1 */



  htim3.Instance = TIM3;



  htim3.Init.Prescaler = 72-1;



  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;



  htim3.Init.Period = 10000-1;



  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;



  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;



  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)



  {



    Error_Handler();



  }



  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;



  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)



  {



    Error_Handler();



  }



  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;



  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;



  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)



  {



    Error_Handler();



  }



  /* USER CODE BEGIN TIM3_Init 2 */







  /* USER CODE END TIM3_Init 2 */







}







/**



  * @brief USART2 Initialization Function



  * @param None



  * @retval None



  */



MX_USART2_UART_Init(void)



{







  /* USER CODE BEGIN USART2_Init 0 */







  /* USER CODE END USART2_Init 0 */







  /* USER CODE BEGIN USART2_Init 1 */







  /* USER CODE END USART2_Init 1 */



  huart2.Instance = USART2;



  huart2.Init.BaudRate = 115200;



  huart2.Init.WordLength = UART_WORDLENGTH_8B;



  huart2.Init.StopBits = UART_STOPBITS_1;



  huart2.Init.Parity = UART_PARITY_NONE;



  huart2.Init.Mode = UART_MODE_TX_RX;



  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;



  huart2.Init.OverSampling = UART_OVERSAMPLING_16;



  if (HAL_UART_Init(&huart2) != HAL_OK)



  {



    Error_Handler();



  }



  /* USER CODE BEGIN USART2_Init 2 */







  /* USER CODE END USART2_Init 2 */







}







/**



  * @brief USART3 Initialization Function



  * @param None



  * @retval None



  */



MX_USART3_UART_Init(void)



{







  /* USER CODE BEGIN USART3_Init 0 */







  /* USER CODE END USART3_Init 0 */







  /* USER CODE BEGIN USART3_Init 1 */







  /* USER CODE END USART3_Init 1 */



  huart3.Instance = USART3;



  huart3.Init.BaudRate = 115200;



  huart3.Init.WordLength = UART_WORDLENGTH_8B;



  huart3.Init.StopBits = UART_STOPBITS_1;



  huart3.Init.Parity = UART_PARITY_NONE;



  huart3.Init.Mode = UART_MODE_TX_RX;



  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;



  huart3.Init.OverSampling = UART_OVERSAMPLING_16;



  if (HAL_UART_Init(&huart3) != HAL_OK)



  {



    Error_Handler();



  }



  /* USER CODE BEGIN USART3_Init 2 */







  /* USER CODE END USART3_Init 2 */







}







/**



  * @brief GPIO Initialization Function



  * @param None



  * @retval None



  */



void MX_GPIO_Init(void)



{



  GPIO_InitTypeDef GPIO_InitStruct = {0};



  /* USER CODE BEGIN MX_GPIO_Init_1 */







  /* USER CODE END MX_GPIO_Init_1 */







  /* GPIO Ports Clock Enable */



  __HAL_RCC_GPIOC_CLK_ENABLE();



  __HAL_RCC_GPIOD_CLK_ENABLE();



  __HAL_RCC_GPIOA_CLK_ENABLE();



  __HAL_RCC_GPIOB_CLK_ENABLE();







  /*Configure GPIO pin Output Level */



  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);







  /*Configure GPIO pin : B1_Pin */



  GPIO_InitStruct.Pin = B1_Pin;



  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;



  GPIO_InitStruct.Pull = GPIO_NOPULL;



  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);







  /*Configure GPIO pin : LD2_Pin */



  GPIO_InitStruct.Pin = LD2_Pin;



  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;



  GPIO_InitStruct.Pull = GPIO_NOPULL;



  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;



  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);







  /* EXTI interrupt init*/



  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);



  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);







  /* USER CODE BEGIN MX_GPIO_Init_2 */







  /* USER CODE END MX_GPIO_Init_2 */



}







/* USER CODE BEGIN 4 */







/* USER CODE END 4 */







/**



  * @brief  This function is executed in case of error occurrence.



  * @retval None



  */



void Error_Handler(void)



{



  /* USER CODE BEGIN Error_Handler_Debug */



  /* User can add his own implementation to report the HAL error return state */



  __disable_irq();



  while (1)



  {



  }



  /* USER CODE END Error_Handler_Debug */



}







#ifdef  USE_FULL_ASSERT



/**



  * @brief  Reports the name of the source file and the source line number



  *         where the assert_param error has occurred.



  * @param  file: pointer to the source file name



  * @param  line: assert_param error line source number



  * @retval None



  */



void assert_failed(uint8_t *file, uint32_t line)



{



  /* USER CODE BEGIN 6 */



  /* User can add his own implementation to report the file name and line number,



     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */



  /* USER CODE END 6 */



}



#endif /* USE_FULL_ASSERT */
