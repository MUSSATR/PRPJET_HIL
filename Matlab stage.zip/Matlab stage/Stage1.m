Ts=0.01
Num =[1];
Den =[0.25 0.8 1];
G = tf(Num ,Den);
Gz = c2d(G, Ts, 'zoh');
step(G)
bode (G);

