/*
 * File: Stage.c
 *
 * Code generated for Simulink model 'Stage'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Wed Jun 25 12:14:39 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Stage.h"
#include "Stage_private.h"

/* Block states (default storage) */
DW_Stage_T Stage_DW;

/* Real-time model */
RT_MODEL_Stage_T Stage_M_;
RT_MODEL_Stage_T *const Stage_M = &Stage_M_;

/* Model step function */
void Stage_step(void)
{
  real_T rtb_PulseGenerator;

  /* DiscretePulseGenerator: '<Root>/Pulse Generator' */
  rtb_PulseGenerator = (Stage_DW.clockTickCounter < Stage_P.PulseGenerator_Duty)
    && (Stage_DW.clockTickCounter >= 0) ? Stage_P.PulseGenerator_Amp : 0.0;
  if (Stage_DW.clockTickCounter >= Stage_P.PulseGenerator_Period - 1.0) {
    Stage_DW.clockTickCounter = 0;
  } else {
    Stage_DW.clockTickCounter++;
  }

  /* End of DiscretePulseGenerator: '<Root>/Pulse Generator' */

  /* S-Function (stm32f4_do_write): '<Root>/GPIO Write' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   */
  MW_GPIO_ToggleBits(0U, 5U, rtb_PulseGenerator != 0.0);
}

/* Model initialize function */
void Stage_initialize(void)
{
  /* Start for S-Function (stm32f4_do_write): '<Root>/GPIO Write' */
  MW_GpioInit(0U, 32U, 1U, 0U, 0U, 0U);
}

/* Model terminate function */
void Stage_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
